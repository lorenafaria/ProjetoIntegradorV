## API Criada por Reinaldo Martins Reis RA 4201315 do Grupo Super Sam
## Criado uma API para utilização da Receita Federal. Foi criada para quando o Imigrante der entrada na 
## Receita Federal o sistema faz um busca pelo ID do imiigrante e veja se existe e caso não exista ele
## ele seja cadastrado no nosso sistema para identifcação desse imigrante
## Esse tipo de cadastro ajudará para saber se O imigrante entrou legal ou ilegamente quando for buscar 
## emprego pelo sistema.

from flask import Flask, request
from flask_restful import reqparse, abort, Api, Resource

from main import insertImigrante
from main import atualizaImigrante
from main import SelectImigrante


app = Flask("Receita")

#Busca dados Imigrante
@app.route("/BuscaImigrante", methods=["GET"])
def BuscaImigrante():
    body = request.get_json()
    if("Codigo" not in body):
        return Retorno(400, "Necessário envio do código do imigrante")
    Codigo =  (body["Codigo"])
    if(Codigo >= 1200): # Condição para ficticia para informar que não existe o Imigrante
           return Retorno(400, "Imigrante não existe no banco de dados")
    else:
        Imigrante = SelectImigrante(body["Codigo"])
        return Retorno(200, "Imgrante encontrado na base", "user" ,Imigrante)


#cadastrar  Imigrante
@app.route("/cadastraUsuario", methods=["PUT"])
def cadastraUsuario():

    body = request.get_json()
    if("nome" not in body):
        return Retorno(400, "O Nome do imigrante é obrigatoria")
    
    if("pais" not in body):
        return Retorno(400, "O Pais de Origem é obrigatoria")

    if("Data_Nasc" not in body):
        return Retorno(400, "A data de nascimento é obrigatoria")

    if("Sexo" not in body):
        return Retorno(400, "A Campo Sexo é obrigatorio")

    Imigrante = insertImigrante(body["nome"], body["pais"], body["Data_Nasc"], body["Sexo"])

    return Retorno(200, "Imigrante Cadastrado com sucesso", "Imigrante" ,Imigrante)

# Atualiza Imigrante base dados
@app.route("/atualiza_imigrante   ", methods=["PUT"])
def atualiza_imigrante():
    insertImigrante = atualizaImigrante
    body = request.get_json()
    
    if("Codigo" not in body):
        return Retorno(400, "Necessário envio do Campo código do imigrante")
    Codigo =  (body["Codigo"]) 
    
    if(Codigo >= 1200): # Condição para ficticia para informar que não existe o Imigrante
           return Retorno(400, "Imigrante não existe no banco de dados")
        
    if(Codigo <= 1200): # Condição para ficticia para informar que não existe o Imigrante
           Imigrante = atualizaImigrante(body["nome"], body["pais"], body["Data_Nasc"], body["Sexo"]) 
           return Retorno(200, "Imigrante Alterado com sucesso", "Imigrante" ,Imigrante)       
         

def Retorno(status, mensagem, nome_do_conteudo=False, conteudo=False):
    response = {}
    response["status"] = status
    response["mensagem"] = mensagem

    if(nome_do_conteudo and conteudo):
        response[nome_do_conteudo] = conteudo
    
    return response

app.run()