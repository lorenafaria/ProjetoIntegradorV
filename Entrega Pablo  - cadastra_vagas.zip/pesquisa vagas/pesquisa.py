from flask import Flask
from flask_restful import reqparse, abort, Api, Resource

app = Flask(__name__)
api = Api(app)

VAGAS = {
    
    'vaga1': {'task': 'Aux producao'},
    'vaga2': {'task': 'motorista'},
    'vaga3': {'task': 'psicologo'}

}

def abort_if_vaga_doesnt_exist(vaga_id):
    if vaga_id not in VAGAS:
        abort(404, message="Vaga {} doesn't exist".format(vaga_id))

parser = reqparse.RequestParser()
parser.add_argument('task')

# Vagas resource
class Vaga(Resource):
    def get(self, vaga_id):
        abort_if_vaga_doesnt_exist(vaga_id)
        return VAGAS[vaga_id]

    def delete(self, vaga_id):
        abort_if_vaga_doesnt_exist(vaga_id)
        del VAGAS[vaga_id]
        return '', 204

    def put(self, vaga_id):
        args = parser.parse_args()
        task = {'task': args['task']}
        VAGAS[vaga_id] = task
        return task, 200

# Vagas list resource
class VagaList(Resource):
    def get(self):
        return VAGAS

    def post(self):
        args = parser.parse_args()
        vaga_id = int(max(VAGAS.keys()).lstrip('vaga')) + 1
        vaga_id = 'vaga%i' % vaga_id
        VAGAS[vaga_id] = {'task': args['task']}
        return VAGAS[vaga_id], 201

# add resources to api
api.add_resource(VagaList, '/vaga')
api.add_resource(Vaga, '/vaga/<vaga_id>')

if __name__ == '__main__':
    app.run(debug=True)